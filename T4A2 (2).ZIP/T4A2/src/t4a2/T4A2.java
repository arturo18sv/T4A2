package t4a2;

import java.util.Scanner;

public class T4A2 {


    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        //jercicio3();
        //ejercicio4();
    }
     public static void ejercicio1() {
    //1.Dise�a una aplicaci�n que muestre las tablas de multiplicar del 1 al 10.
    Scanner scanner = new Scanner(System.in);
    
    System.out.print("Ejecutor de tabla de tablas de multiplicar ");
   
     for(int i = 1; i<11; i++) {
         
         System.out.println("Es la tabla de " + i);
         
             for (int j = 1; j <11; j++) {
                 System.out.println(i + " x " + j + " = " + (i*j));
         }
           System.out.println("\n");                                      
        }
}
       public static void ejercicio2() {
  
int inicio, fin, contador = 0;

		Scanner sc = new Scanner(System.in);
                
		System.out.println("Escribe el inicio:");
		inicio = sc.nextInt();
		System.out.println("Escribe el fin:");
		fin = sc.nextInt();
                
		for (int x = inicio; x <= fin; x++) {
			if (esPrimo(x)) {
				contador++;
				System.out.print(String.valueOf(x) + ",");
			}
		}
		System.out.printf("\nTotal: %d \n", contador);
		sc.close();
	}

	public static boolean esPrimo(int numero) {
		
		if (numero == 0 || numero == 1 || numero == 4) {
			return false;
		}
		for (int x = 2; x < numero / 2; x++) {

			if (numero % x == 0)
				return false;
		}
		
		return true;
	}

         public static void ejercicio3() {
   
      Scanner scanner = new Scanner(System.in);
      
    int cant, num, pares=0, impares=0;
    System.out.print("Cuantos numeros desea ingresar: ");
    cant = scanner.nextInt();
    
    for(int i=1; i<=cant; i++){
     System.out.print("Ingresar numero " + i + " de " + cant + ": ");
      num = (new Scanner(System.in)).nextInt();
      
       if(num%2 == 0)
         pares++;
       else
         impares++; }
         
    System.out.println("\nCantidad de numeros pares: " + pares);
    System.out.println("Cantidad de numeros impares: " + impares); 
         } 


           public static void ejercicio4() {
    
    
    Scanner tec = new Scanner (System.in);
    String palabra;
    String invert = " ";
    
    System.out.print("Ingrese una palabra: ");
    palabra =  tec.nextLine();
    
    for (int contador = palabra.length()-1; contador >=0; contador--) {
        invert = invert + palabra.charAt (contador);
        
    }
    System.out.println(invert);
    
           }
           
}
